# Pesquisa de Satisfação

Aplicação web simples para recolher avaliações (1 a 5 estrelas) e comentários, e apresentar um resumo dos resultados em tempo real.

**Instituição:** Instituto Superior Politécnico de Tete (ISPT)
**Curso:** Engenharia Informática, 1.º ano, Pós-laboral
**Disciplina:** Algoritmo e Lógica de Programação
**Docente:** Luís Nhacanhaca

## Funcionalidades

- Formulário com nome (opcional), classificação por estrelas (obrigatória) e comentário (opcional)
- Validação: não permite enviar sem classificação
- Resumo automático: média, total de avaliações e nível geral (Excelente, Bom, Razoável ou Fraco)
- Distribuição por nota em barras
- Lista de comentários, dos mais recentes para os mais antigos
- Dados guardados no navegador (`localStorage`) e botão para apagar todas as respostas
- Interface responsiva, com modo claro e escuro automático

## Como executar

Não precisa de instalação. Faça download do repositório e abra o `index.html` num navegador.

Para publicar online com GitHub Pages: **Settings > Pages > Branch: main > / (root) > Save**.

## Estrutura

```
pesquisa-satisfacao/
├── index.html        # Estrutura da página
├── style.css         # Estilos
├── script.js         # Lógica em JavaScript
├── docs/
│   ├── Documento_Planeamento.pdf                 # Capa, problema, fluxograma, pseudocódigo e divisão de tarefas
│   ├── Planeamento.md                            # Versão em texto do planeamento
│   └── Pesquisa_Satisfacao_ficheiro_unico.html   # Versão com HTML, CSS e JS num só ficheiro
├── .gitignore
├── LICENSE
└── README.md
```

## Equipa e divisão de tarefas

| Membro | Responsabilidade |
|---|---|
| Valdino Elias | Análise do problema e fluxograma |
| Alssides Jone | Pseudocódigo, interface HTML e estilos CSS |
| Dercio Bochana | Codificação inicial em JavaScript e testes |

## Próximos passos

- Exportar resultados para ficheiro
- Filtrar comentários por nota
- Adicionar mais perguntas e gráficos

## Licença

Distribuído sob a licença MIT. Veja o ficheiro `LICENSE`.
