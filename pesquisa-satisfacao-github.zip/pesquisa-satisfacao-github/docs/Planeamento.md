# Pesquisa de Satisfação — Planeamento e Divisão de Tarefas

## 1. Descrição do problema

Uma pequena empresa (por exemplo, um café ou uma escola) quer saber se os clientes estão satisfeitos, mas recolhe opiniões de forma informal e sem registo. Não consegue calcular uma média, ver quantas pessoas deram cada nota nem ler os comentários num só sítio.

**Solução proposta:** uma página web onde o utilizador dá uma nota de 1 a 5 estrelas e escreve um comentário. O programa em JavaScript valida os dados, guarda-os e apresenta de imediato um resumo com média, total de avaliações, nível geral (Excelente, Bom, Razoável, Fraco), distribuição por nota e lista de comentários.

**Entradas:** nome (opcional), nota (obrigatória), comentário (opcional).
**Saídas:** média, total, nível geral, barras por nota, lista de comentários.

## 2. Fluxograma

```mermaid
flowchart TD
  A([Início]) --> B[Carregar respostas guardadas]
  B --> C[Mostrar resumo e comentários]
  C --> D{Utilizador envia avaliação?}
  D -- Não --> C
  D -- Sim --> E{Nota escolhida?}
  E -- Não --> F[Mostrar erro] --> C
  E -- Sim --> G[Criar resposta: nome, nota, comentário, data]
  G --> H[Guardar na lista e no armazenamento]
  H --> I[Recalcular média, total e distribuição]
  I --> J[Atualizar ecrã e limpar formulário]
  J --> C
```

## 3. Pseudocódigo

```
INÍCIO
  respostas ← carregar do armazenamento (ou lista vazia)
  MOSTRAR resumo(respostas)

  REPETIR quando o utilizador clica em "Enviar"
    SE nota = 0 ENTÃO
      MOSTRAR "Escolha uma classificação"
    SENÃO
      nome ← nome introduzido, ou "Anónimo" se vazio
      nova ← {nome, nota, comentário, data de hoje}
      ADICIONAR nova a respostas
      GUARDAR respostas
      LIMPAR formulário
      MOSTRAR resumo(respostas)
    FIM SE
  FIM REPETIR
FIM

FUNÇÃO resumo(lista)
  total ← tamanho de lista
  SE total = 0 ENTÃO media ← 0
  SENÃO media ← soma das notas / total
  PARA n DE 5 ATÉ 1
    contagem[n] ← número de respostas com nota n
    percentagem[n] ← contagem[n] / total × 100
  FIM PARA
  nível ← SE media ≥ 4,5 "Excelente"
          SENÃO SE media ≥ 3,5 "Bom"
          SENÃO SE media ≥ 2,5 "Razoável"
          SENÃO "Fraco"
  MOSTRAR media, total, nível, barras, comentários (mais recentes primeiro)
FIM FUNÇÃO
```

## 4. Relatório: divisão de tarefas

**Grupo:** Valdino Elias, Alssides Jone e Dercio Bochana

| Membro | Responsabilidade | Entrega |
|---|---|---|
| Valdino Elias | Análise do problema (entradas e saídas) e desenho do fluxograma | Secções 1 e 2 deste documento |
| Alssides Jone | Pseudocódigo, interface HTML e estilos CSS | Secção 3, `index.html` e `style.css` |
| Dercio Bochana | Codificação inicial em JavaScript e testes de funcionamento | `script.js` e lista de testes |

**Organização:** o grupo reuniu para definir o problema e a solução. Cada elemento fez a sua parte e a integração final foi feita em conjunto, testando o formulário com várias notas e comentários.

**Entrega final:** os três ficheiros (HTML, CSS e JS) foram reunidos num único ficheiro, `Pesquisa_Satisfacao.html`, que se executa abrindo-o em qualquer navegador.

**Estado atual:** a primeira versão valida a nota, guarda as respostas no navegador (localStorage) e mostra o resumo em tempo real.

**Próximos passos:** exportar resultados para ficheiro, filtrar comentários por nota, adicionar mais perguntas e gráficos.
