// Pesquisa de Satisfação - versão inicial
// Os dados ficam guardados no localStorage do navegador.

const CHAVE = "pesquisaSatisfacao";
let respostas = carregar();
let notaEscolhida = 0;

const formulario = document.getElementById("formulario");
const estrelas = document.querySelectorAll("#estrelas button");
const erro = document.getElementById("erro");

// ---------- Armazenamento ----------
function carregar() {
  try {
    return JSON.parse(localStorage.getItem(CHAVE)) || [];
  } catch (e) {
    return [];
  }
}

function guardar() {
  try {
    localStorage.setItem(CHAVE, JSON.stringify(respostas));
  } catch (e) {
    // Se não for possível guardar, os dados mantêm-se só nesta sessão.
  }
}

// ---------- Cálculos ----------
function calcularMedia(lista) {
  if (lista.length === 0) return 0;
  const soma = lista.reduce((acc, r) => acc + r.nota, 0);
  return soma / lista.length;
}

function contarPorNota(lista) {
  const contagem = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  lista.forEach((r) => contagem[r.nota]++);
  return contagem;
}

function classificar(media) {
  if (media >= 4.5) return "Excelente";
  if (media >= 3.5) return "Bom";
  if (media >= 2.5) return "Razoável";
  return "Fraco";
}

// ---------- Interface ----------
function pintarEstrelas(valor) {
  estrelas.forEach((b) => {
    b.classList.toggle("ativa", Number(b.dataset.valor) <= valor);
  });
}

function mostrarResumo() {
  const media = calcularMedia(respostas);
  document.getElementById("total").textContent = respostas.length;
  document.getElementById("media").textContent =
    respostas.length ? media.toFixed(1).replace(".", ",") : "–";
  document.getElementById("nivel").textContent =
    respostas.length ? classificar(media) : "–";

  const contagem = contarPorNota(respostas);
  const barras = document.getElementById("barras");
  barras.innerHTML = "";
  for (let n = 5; n >= 1; n--) {
    const pct = respostas.length ? (contagem[n] / respostas.length) * 100 : 0;
    const linha = document.createElement("div");
    linha.className = "barra";
    linha.innerHTML =
      `<span>${n} ★</span>` +
      `<div class="fundo"><div class="cheio" style="width:${pct}%"></div></div>` +
      `<span>${contagem[n]}</span>`;
    barras.appendChild(linha);
  }
}

function mostrarComentarios() {
  const lista = document.getElementById("lista");
  lista.innerHTML = "";
  const comTexto = respostas.filter((r) => r.comentario);

  if (comTexto.length === 0) {
    lista.innerHTML =
      '<li class="vazio">Ainda não há comentários. Seja o primeiro a avaliar.</li>';
    return;
  }
  // Mais recentes primeiro
  comTexto.slice().reverse().forEach((r) => {
    const li = document.createElement("li");
    const meta = document.createElement("div");
    meta.className = "meta";
    meta.textContent = `${r.nome} · ${"★".repeat(r.nota)} · ${r.data}`;
    const texto = document.createElement("div");
    texto.textContent = r.comentario; // textContent evita injeção de HTML
    li.append(meta, texto);
    lista.appendChild(li);
  });
}

function atualizar() {
  mostrarResumo();
  mostrarComentarios();
}

// ---------- Eventos ----------
estrelas.forEach((b) => {
  b.addEventListener("click", () => {
    notaEscolhida = Number(b.dataset.valor);
    pintarEstrelas(notaEscolhida);
    erro.textContent = "";
  });
});

formulario.addEventListener("submit", (e) => {
  e.preventDefault();

  if (notaEscolhida === 0) {
    erro.textContent = "Escolha uma classificação de 1 a 5 estrelas.";
    return;
  }

  const nome = document.getElementById("nome").value.trim();
  const comentario = document.getElementById("comentario").value.trim();

  respostas.push({
    nome: nome || "Anónimo",
    nota: notaEscolhida,
    comentario: comentario,
    data: new Date().toLocaleDateString("pt-PT"),
  });
  guardar();

  formulario.reset();
  notaEscolhida = 0;
  pintarEstrelas(0);
  erro.textContent = "";
  atualizar();
});

document.getElementById("limpar").addEventListener("click", () => {
  if (respostas.length && confirm("Apagar todas as respostas?")) {
    respostas = [];
    guardar();
    atualizar();
  }
});

atualizar();
